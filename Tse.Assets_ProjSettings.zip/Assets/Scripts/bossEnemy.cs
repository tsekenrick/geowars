﻿using UnityEngine;
using System.Collections;
using UnityEngine.SceneManagement;

public class bossEnemy : MonoBehaviour
{
    public GameObject gun;
    public GameObject gun2;
    public GameObject gun3;
    public GameObject enemyBullet;

    public float health;
    Vector3 homePos;
    public float moveSpeed;
    public bool goRight;

    public bool canLaunch;
    public float attackSpeed;
    public float bulletUpSpeed;
    public float bulletSpeed;

    int frames;

    // Use this for initialization
    void Start()
    {
        homePos = transform.position;
        canLaunch = true;

        InvokeRepeating("flip", 0f, 10f);
        InvokeRepeating("unflip", 5f, 10f);
    }

    // Update is called once per frame
    void Update()
    {
        frames++;
        Debug.Log(health);

        if (health <= 0)
        {
            SceneManager.LoadScene("winScreen");
        }

        /*if (homePos.x + 5f < transform.position.x)
        {
            goRight = false;
        }

        if (homePos.x - 5f > transform.position.x)
        {
            goRight = true;
        }

        if (goRight)
        {
            transform.rotation = new Quaternion(transform.rotation.x, 0, transform.rotation.z, transform.rotation.w);
            transform.position += moveSpeed * Vector3.right * Time.deltaTime;
        }

        if (goRight == false)
        {
            transform.rotation = new Quaternion(transform.rotation.x, 180, transform.rotation.z, transform.rotation.w);
            transform.position += moveSpeed * Vector3.left * Time.deltaTime;
        }*/



        if (canLaunch && frames % 30 == 0)
        {
            GameObject temp = (GameObject)Instantiate(enemyBullet, gun.transform.position, Quaternion.identity);
            if (transform.rotation.y != 0)
            {
                temp.GetComponent<Rigidbody2D>().AddForce(Vector2.left * bulletSpeed);
            }

            if (transform.rotation.y == 0)
            {
                temp.GetComponent<Rigidbody2D>().AddForce(Vector2.right * bulletSpeed);
            }


            GameObject temp2 = (GameObject)Instantiate(enemyBullet, gun2.transform.position, Quaternion.identity);

            if (transform.rotation.y != 0)
            {
                temp2.GetComponent<Rigidbody2D>().AddForce(Vector2.left * bulletSpeed);
                temp2.GetComponent<Rigidbody2D>().AddForce(Vector2.up * bulletUpSpeed);
            }

            if (transform.rotation.y == 0)
            {
                temp2.GetComponent<Rigidbody2D>().AddForce(Vector2.right * bulletSpeed);
                temp2.GetComponent<Rigidbody2D>().AddForce(Vector2.up * bulletUpSpeed);
            }


            GameObject temp3 = (GameObject)Instantiate(enemyBullet, gun3.transform.position, Quaternion.identity);
            if (transform.rotation.y != 0)
            {
                temp3.GetComponent<Rigidbody2D>().AddForce(Vector2.left * bulletSpeed);
                temp3.GetComponent<Rigidbody2D>().AddForce(Vector2.down * bulletUpSpeed);
            }

            if (transform.rotation.y == 0)
            {
                temp3.GetComponent<Rigidbody2D>().AddForce(Vector2.right * bulletSpeed);
                temp3.GetComponent<Rigidbody2D>().AddForce(Vector2.down * bulletUpSpeed);
            }
            Invoke("stopBurst", 3f);
        }
    }

    void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.name == "player")
        {
            collision.gameObject.GetComponent<playerMovement>().decreaseHealth();
        }

    }

    void shootingReset()
    {
        CancelInvoke("stopBurst");
        canLaunch = true;
    }

    void stopBurst()
    {
        canLaunch = false;
        Invoke("shootingReset", attackSpeed);
    }

    void flip()
    {
        transform.rotation = new Quaternion(transform.rotation.x, 180, transform.rotation.z, transform.rotation.w);
    }

    void unflip()
    {
        transform.rotation = new Quaternion(transform.rotation.x, 0, transform.rotation.z, transform.rotation.w);
    }

    public void decreaseHealth()
    {
        health--;
    }

}
