﻿using UnityEngine;
using System.Collections;
using UnityEngine.SceneManagement;

public class manager2 : MonoBehaviour {

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update ()
    {
        if (Input.GetKey(KeyCode.R))
        {
            SceneManager.LoadScene("game");
            PlayerPrefs.SetInt("hasDoubleJump", 0);
            PlayerPrefs.SetInt("hasRangedAttack", 0);
        }
    }
}

