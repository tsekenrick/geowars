﻿using UnityEngine;
using System.Collections;

public class bulletSpawn : MonoBehaviour {
    public GameObject bullet;
    public bool canLaunch;
    public float attackSpeed;
    public GameObject player;
    public float bulletSpeed;
    public float moralityCheck;
    // Use this for initialization
    void Start(){
        canLaunch = true;

    }

    // Update is called once per frame
    void Update() {

        moralityCheck = PlayerPrefs.GetInt("hasRangedAttack");
        if (canLaunch && Input.GetMouseButtonDown(1) && moralityCheck == 0)
        {
            GameObject temp = (GameObject)Instantiate(bullet, transform.position, Quaternion.identity);
            
            if (player.GetComponent<playerMovement>().leftFacing)
            {
                temp.GetComponent<Rigidbody2D>().AddForce(Vector2.left * bulletSpeed);
            }

            if (player.GetComponent<playerMovement>().rightFacing)
            {
                temp.GetComponent<Rigidbody2D>().AddForce(Vector2.right * bulletSpeed);
            }


            canLaunch = false;
            Invoke("shootingReset", attackSpeed);
        }
	}
        
    void shootingReset()
    {
        canLaunch = true;
    }
}
