﻿using UnityEngine;
using System.Collections;
using UnityEngine.SceneManagement;

public class manager : MonoBehaviour {
    int currentStage;
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {

    currentStage = SceneManager.GetActiveScene().buildIndex;
	if (Input.GetKey(KeyCode.T))
        {
            SceneManager.LoadScene(currentStage +1);
        }
	}

    public void loadLevel(string scenename)
    {
        SceneManager.LoadScene(scenename);
    }
}
