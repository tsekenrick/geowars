﻿using UnityEngine;
using System.Collections;

public class meleeEnemy : MonoBehaviour {
    Vector3 homePos;
    public bool goRight;
    Rigidbody2D rb;

    public GameObject player;

    public float health;
    public float moveSpeed = 1f;
    public float distBetween;
    public float aggroRangeUpper;
    public float aggroRangeLower;
    public float aggroMoveSpeed;
    public float deaggroRange;
    // Use this for initialization
    void Start () {
        homePos = transform.position;
        rb = GetComponent<Rigidbody2D>();

        
    }

    // Update is called once per frame
    void Update()
    {

        Invoke("scoutMode", 0f);

        if (health <= 0)
        {
            Destroy(this.gameObject);
        }

        distBetween = player.transform.position.x - transform.position.x;

        if (distBetween < aggroRangeUpper && distBetween > aggroRangeLower)
        {
            Invoke("aggroMode", 0f);

            if (distBetween < deaggroRange && distBetween > -deaggroRange)
            {
                Invoke("aggroMode", 0f);
            }
        }

       

        //velocity = new vector3 (0, Mathf.Sin(Time.time *1f)*1.5f,0); code for oscillation in the y axis, *8f is to increase period of the sine function (from 2pi to 2pi*8), *1.5f changes amplitude

    }

    void OnCollisionEnter2D (Collision2D collision)
    {

        if (collision.gameObject.name == "player")
        {
            collision.gameObject.GetComponent<playerMovement>().decreaseHealth();
        }
            
    }

    void scoutMode()
    {
        if (homePos.x + 2f < transform.position.x)
        {
            goRight = false;
        }

        if (homePos.x - 2f > transform.position.x)
        {
            goRight = true;
        }

        if (goRight)
        {
            transform.rotation = new Quaternion(transform.rotation.x, 0, transform.rotation.z, transform.rotation.w);
            transform.position += moveSpeed * Vector3.right * Time.deltaTime;
        }

        if (goRight == false)
        {
            transform.rotation = new Quaternion(transform.rotation.x, 180, transform.rotation.z, transform.rotation.w);
            transform.position += moveSpeed * Vector3.left * Time.deltaTime;
        }
    }

    void aggroMode()
    {
        

        if (distBetween > 0)
        {
            transform.rotation = new Quaternion(transform.rotation.x, 0, transform.rotation.z, transform.rotation.w);
            transform.position = Vector2.MoveTowards(new Vector2(transform.position.x, transform.position.y), new Vector2(player.transform.position.x, transform.position.y), aggroMoveSpeed * Time.deltaTime);
        }

        if (distBetween < 0)
        {
            transform.rotation = new Quaternion(transform.rotation.x, 180, transform.rotation.z, transform.rotation.w);
            transform.position = Vector2.MoveTowards(new Vector2(transform.position.x, transform.position.y), new Vector2(player.transform.position.x, transform.position.y), aggroMoveSpeed * Time.deltaTime);
        }
    }


    public void decreaseHealth()
    {
        health--;
    }
}
