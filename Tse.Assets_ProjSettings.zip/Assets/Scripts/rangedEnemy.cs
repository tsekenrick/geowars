﻿using UnityEngine;
using System.Collections;

public class rangedEnemy : MonoBehaviour {
    public GameObject player;
    public GameObject gun;
    public GameObject enemyBullet;

    public float health;
    Vector3 homePos;
    public float distBetween;
    public float aggroRangeUpper;
    public float aggroRangeLower;
    public float aggroMoveSpeed;
    public float moveSpeed;

    public bool goRight;

    public bool canLaunch;
    public float attackSpeed;
    public float bulletUpSpeed;
    public float bulletSpeed;
    // Use this for initialization
    void Start () {
        canLaunch = true;
        homePos = transform.position;
    }
	
	// Update is called once per frame
	void Update () {

        if (health <= 0)
        {
            Destroy(this.gameObject);
        }

        distBetween = player.transform.position.x - transform.position.x;

        if (distBetween<aggroRangeUpper && distBetween > aggroRangeLower)
        {
            Invoke("aggroMode", 0f);
        }
        else
        {
            Invoke("scoutMode", 0f);
        }
	}
    
    void aggroMode()
    {
        if (distBetween > 0)
        {
            transform.rotation = new Quaternion(transform.rotation.x, 0, transform.rotation.z, transform.rotation.w);
            transform.position = Vector2.MoveTowards(new Vector2(transform.position.x, transform.position.y), new Vector2(player.transform.position.x - 5, transform.position.y), aggroMoveSpeed * Time.deltaTime);
        }

        if (distBetween < 0)
        {
            transform.rotation = new Quaternion(transform.rotation.x, 180, transform.rotation.z, transform.rotation.w);
            transform.position = Vector2.MoveTowards(new Vector2(transform.position.x, transform.position.y), new Vector2(player.transform.position.x + 5, transform.position.y), aggroMoveSpeed * Time.deltaTime);
        }

        Invoke("shooting", 0f);

    }

    public void shooting()
    {

        if (canLaunch)
        {
            GameObject temp = (GameObject)Instantiate(enemyBullet, gun.transform.position, Quaternion.identity);

            if (transform.rotation.y != 0)
            {
                temp.GetComponent<Rigidbody2D>().AddForce(Vector2.left * bulletSpeed);
                temp.GetComponent<Rigidbody2D>().AddForce(Vector2.up * bulletUpSpeed, ForceMode2D.Impulse);
            }

            if (transform.rotation.y == 0)
            {
                temp.GetComponent<Rigidbody2D>().AddForce(Vector2.right * bulletSpeed);
                temp.GetComponent<Rigidbody2D>().AddForce(Vector2.up * bulletUpSpeed, ForceMode2D.Impulse);
            }


            canLaunch = false;
            Invoke("shootingReset", attackSpeed);
        }
    }

    void shootingReset()
    {
        canLaunch = true;
    }

    void scoutMode()
    {
        if (homePos.x + 2f < transform.position.x)
        {
            goRight = false;
        }

        if (homePos.x - 2f > transform.position.x)
        {
            goRight = true;
        }

        if (goRight)
        {
            transform.rotation = new Quaternion(transform.rotation.x, 0, transform.rotation.z, transform.rotation.w);
            transform.position += moveSpeed * Vector3.right * Time.deltaTime;
        }

        if (goRight == false)
        {
            transform.rotation = new Quaternion(transform.rotation.x, 180, transform.rotation.z, transform.rotation.w);
            transform.position += moveSpeed * Vector3.left * Time.deltaTime;
        }
    }

    void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.name == "player")
        {
            collision.gameObject.GetComponent<playerMovement>().decreaseHealth();
        }

    }

    public void decreaseHealth()
    {
        health--;
    }
}
