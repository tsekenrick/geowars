﻿using UnityEngine;
using System.Collections;

public class bossHealth : MonoBehaviour {
    public GameObject boss;
    public TextMesh textBox;
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
        textBox.text = boss.GetComponent<bossEnemy>().health.ToString();
        transform.rotation = new Quaternion(transform.rotation.x, 0, transform.rotation.z, transform.rotation.w);
	}
}
