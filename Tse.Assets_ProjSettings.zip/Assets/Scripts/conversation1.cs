﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class conversation1 : MonoBehaviour {
    public GameObject textBox;
    public Text theText;

    public TextAsset firstConvo;
    public string[] convoLines;

    public int currentLine;
    public int endLine;

    public GameObject goodButton;
    public GameObject badButton;
    public Transform canvas;

    public float canRangedAttack;

    bool stopSpawn = false;
	// Use this for initialization
	void Start () {
	    if (firstConvo != null)
        {
            convoLines = (firstConvo.text.Split('\n'));
        }

        endLine = convoLines.Length - 1;

        

    }

    public void goodChoice()
    {
        //PlayerPrefs.SetInt("hasDoubleJump", 0);
        Debug.Log("works)");
        PlayerPrefs.SetInt("hasRangedAttack", 1);
        GameObject.FindGameObjectWithTag("GameController").GetComponent<manager>().loadLevel("level2");
    }

    public void badChoice()
    {
        Debug.Log("also works");
        PlayerPrefs.SetInt("hasRangedAttack", 0);
        GameObject.FindGameObjectWithTag("GameController").GetComponent<manager>().loadLevel("level2");
    }

    // Update is called once per frame
    void Update () {

        theText.text = convoLines[currentLine];

        if (Input.GetKeyDown(KeyCode.Space) || Input.GetKeyDown(KeyCode.Return))
        {
            currentLine++;
        }

        if (currentLine == endLine && stopSpawn == false)
        {
            Invoke("buttonSpawn", 0f);
        }

        canRangedAttack = PlayerPrefs.GetInt("hasRangedAttack");
        Debug.Log(canRangedAttack);
	}

    void buttonSpawn()
    {
        GameObject temp = (GameObject)Instantiate(goodButton, new Vector3(-100, -65, 0), Quaternion.identity);
        GameObject temp2 = (GameObject)Instantiate(badButton, new Vector3(100, -65, 0), Quaternion.identity);
        temp.transform.SetParent(canvas, false);
        temp2.transform.SetParent(canvas, false);
        stopSpawn = true;
    }
}
