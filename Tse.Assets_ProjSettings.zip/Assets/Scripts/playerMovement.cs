﻿using UnityEngine;
using System.Collections;
using UnityEngine.SceneManagement;


public class playerMovement : MonoBehaviour {
    //float xVelocity;
    //float acceleration = 50f;   
    public float canDoubleJump = 1f;
    bool inAir = false;

    public float health;
    public float drag;//this will need to change
    public float moveSpeed;
    public float friction;//this will need to change
    public float wallJumpForce;
    public float jumpHeight;
    public float hurtForce;
    public float hurtForceUp;
    public float wallJumpHeight;

    public float moralityCheck2;

    public bool canHurt;
    public bool leftFacing;
    public bool rightFacing;
    public bool interactMode;

    public GameObject sword;

    public Sprite idlesprite;
    public Sprite meleesprite;

    public LayerMask rayMask;

    RaycastHit2D hit;
    RaycastHit2D hitLeft;
    RaycastHit2D hit2;
    RaycastHit2D hit3;
    RaycastHit2D hitLeft2;
    RaycastHit2D hitLeft3;


    Rigidbody2D rb;
    // Use this for initialization
    void Start () {
        leftFacing = false;
        rightFacing = true;
        interactMode = false;
        canHurt = true;
        rb = GetComponent<Rigidbody2D>();
    }
	
	// Update is called once per frame
	void Update () {

        //PlayerPrefs.SetInt ("HasDoubleJump", 1);

        //int doubleJump = PlayerPrefs.GetInt ("HasDoubleJump");
        //if (doubleJump==1){
        
        /*if (PlayerPrefs.GetInt("hasDoubleJump") == 0)
        {
            canDoubleJump = -1;
        }*/
        GetComponent<BoxCollider2D>().sharedMaterial.friction = .5f;
        Debug.DrawRay(transform.position, Vector3.right * .6f, Color.red);
        RaycastHit2D hit = Physics2D.Raycast(transform.position, Vector2.right, .6f, rayMask);
        if (hit)
        {
           if (hit.transform.tag == "ground" || hit.transform.tag == "wall")
            {
                Debug.Log("touching wall to right");
                GetComponent<BoxCollider2D>().sharedMaterial.friction = 0.5f;
            }                           

        }

        Debug.DrawRay(transform.position, Vector3.left * .6f, Color.red);
        RaycastHit2D hitLeft = Physics2D.Raycast(transform.position, Vector2.left, .6f, rayMask);
        if (hitLeft)
        {
            if (hitLeft.transform.tag == "ground" || hitLeft.transform.tag == "wall")
            {
                Debug.Log(hitLeft);
                GetComponent<BoxCollider2D>().sharedMaterial.friction = 0.5f;
            }

        }

        Vector3 lowRay = new Vector3(transform.position.x, transform.position.y - .75f, transform.position.z);
        Debug.DrawRay(lowRay, Vector3.right * .6f, Color.red);
        RaycastHit2D hit2 = Physics2D.Raycast(lowRay, Vector2.right, .6f, rayMask);
        if (hit2)
        {
            if (hit2.transform.tag == "ground" || hit2.transform.tag == "wall")
            {
                Debug.Log("touching wall to right");
                GetComponent<BoxCollider2D>().sharedMaterial.friction = 0.5f;
            }

        }

        Debug.DrawRay(lowRay, Vector3.left * .6f, Color.red);
        RaycastHit2D hitLeft2 = Physics2D.Raycast(lowRay, Vector2.left, .6f, rayMask);
        if (hitLeft2)
        {
            if (hitLeft2.transform.tag == "ground" || hitLeft2.transform.tag == "wall")
            {
                Debug.Log(hitLeft2);
                GetComponent<BoxCollider2D>().sharedMaterial.friction = 0.5f;
            }

        }

        Vector3 highRay = new Vector3(transform.position.x, transform.position.y + .75f, transform.position.z);
        Debug.DrawRay(highRay, Vector3.right * .6f, Color.red);
        RaycastHit2D hit3 = Physics2D.Raycast(highRay, Vector2.right, .6f, rayMask);
        if (hit3)
        {
            if (hit3.transform.tag == "ground" || hit3.transform.tag == "wall")
            {
                Debug.Log("touching wall to right");
                GetComponent<BoxCollider2D>().sharedMaterial.friction = 0.5f;
            }

        }

        Debug.DrawRay(highRay, Vector3.left * .6f, Color.red);
        RaycastHit2D hitLeft3 = Physics2D.Raycast(highRay, Vector2.left, .6f, rayMask);
        if (hitLeft3)
        {
            if (hitLeft3.transform.tag == "ground" || hitLeft3.transform.tag == "wall")
            {
                Debug.Log(hitLeft3);
                GetComponent<BoxCollider2D>().sharedMaterial.friction = 0.5f;
            }

        }

        if (canDoubleJump >= 0)
        {
            if (Input.GetKeyDown(KeyCode.Space))
            {
                if (hitLeft || hitLeft2 || hitLeft3 || hit || hit2 || hit3)
                {
                    Invoke("walljump", 0f);
                    Invoke("jump", 0f);
                }
                else
                {
                    Invoke("jump", 0f);
                    canDoubleJump--;
                }               
            }
        }

        if (Input.GetKeyDown(KeyCode.W))
        {
            interactMode = true;
        }

        if (Input.GetKeyUp(KeyCode.W))
        {
            interactMode = false;
        }

        if (Input.GetKey(KeyCode.D))
        {
            if (inAir == false)
            {
                rb.AddForce(Vector2.right * moveSpeed);
            }

            if (inAir == true)
            {
                rb.AddForce(Vector2.right * moveSpeed);
            }

            transform.rotation = new Quaternion(transform.rotation.x, 0, transform.rotation.z, transform.rotation.w);
            rightFacing = true;
            leftFacing = false;
        }

        if (Input.GetKey(KeyCode.A))
        {

            if (inAir == false)
            {
                rb.AddForce(Vector2.left * moveSpeed);
            }

            if (inAir == true)
            {
                rb.AddForce(Vector2.left * moveSpeed);
            }

            transform.rotation = new Quaternion(transform.rotation.x, 180, transform.rotation.z, transform.rotation.w);
            leftFacing = true;
            rightFacing = false;
        }


        if (inAir)
        {
            //apply drag           
            rb.AddForce(drag * rb.velocity.normalized * rb.velocity.sqrMagnitude); //this force increases as the rigidbody moves faster

        }

        if (inAir==false)
        {
            //apply friction
            rb.AddForce(friction * rb.velocity.normalized * rb.velocity.sqrMagnitude); //this force increases as the rigidbody moves faster

        }

        if (health <= 0 && SceneManager.GetActiveScene().buildIndex != 6)
        {
            SceneManager.LoadScene("failScreenNormal");
        }

        if (health<=0 && SceneManager.GetActiveScene().buildIndex == 6)
        {
            SceneManager.LoadScene("failScreenBoss");
        }
        
    }

    void jump()
    {
        rb.AddForce(Vector2.up * jumpHeight, ForceMode2D.Impulse);

        moralityCheck2 = PlayerPrefs.GetInt("hasDoubleJump");
        if (moralityCheck2 == 1f)
        {
            canDoubleJump = -1f;
        }
    }

    void walljump()
    {
        if (rightFacing)
        {
            rb.AddForce(Vector2.left * wallJumpForce, ForceMode2D.Impulse);
            rb.AddForce(Vector2.up * wallJumpHeight, ForceMode2D.Impulse);
        }

        if (leftFacing)
        {
            rb.AddForce(Vector2.right * wallJumpForce, ForceMode2D.Impulse);
            rb.AddForce(Vector2.up * wallJumpHeight, ForceMode2D.Impulse);
        }
        
    }

    void OnCollisionExit2D (Collision2D collision)
    {
        if (collision.gameObject.tag == "ground")
        {
            inAir = true;
        }
        
    }

    void OnCollisionEnter2D (Collision2D collision)
    {
        if (collision.gameObject.tag == "ground")
        {
            inAir = false;
            canDoubleJump=1f;
        }

        if (collision.gameObject.tag == "wall")
        {
            inAir = true;
            canDoubleJump=1f;
        }

        if (collision.gameObject.tag == "enemy" || collision.gameObject.tag == "meleeEnemy")
        {
            if (collision.gameObject.transform.position.x > transform.position.x)
            {
                rb.AddForce(Vector2.left * hurtForce, ForceMode2D.Impulse);
                rb.AddForce(Vector2.up * hurtForceUp, ForceMode2D.Impulse);
            }

            if (collision.gameObject.transform.position.x < transform.position.x)
            {
                rb.AddForce(Vector2.right * hurtForce, ForceMode2D.Impulse);
                rb.AddForce(Vector2.up * hurtForceUp, ForceMode2D.Impulse);
            }
        }
    }


    public void decreaseHealth()
    {
        if (canHurt)
        {
            health--;
            canHurt = false;
            Invoke("iFramesOff", 1f);
        }                              
    }

    void iFramesOff()
    {
        canHurt = true;
    }
}
