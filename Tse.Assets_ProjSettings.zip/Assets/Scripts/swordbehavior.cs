﻿using UnityEngine;
using System.Collections;

public class swordbehavior : MonoBehaviour {
    bool fightmode;
    public GameObject player;
    public bool meleeAllowed;
    public float attackSpeed;

    public float hurtForce;
    public float hurtForceUp;
    // Use this for initialization
    void Start () {
        fightmode = false;
        meleeAllowed = true;
    }
	
	// Update is called once per frame
	void Update () {
        if (meleeAllowed == true && Input.GetMouseButtonDown(0))
        {
            if (player.GetComponent<playerMovement>().leftFacing == false)
            {
                fightmode = true;
                transform.position = new Vector3(transform.position.x + .6f, transform.position.y, transform.position.z);
                Invoke("reset", attackSpeed);
            }

            if (player.GetComponent<playerMovement>().leftFacing == true)
            {
                fightmode = true;
                transform.position = new Vector3(transform.position.x - .6f, transform.position.y, transform.position.z);
                Invoke("reset", attackSpeed);
            }

            meleeAllowed = false;
            Invoke("meleeReset", attackSpeed);
        }
    }

    void reset()
    {
        fightmode = false;
        if (player.GetComponent<playerMovement>().leftFacing == false)
        {
            transform.position = new Vector3(transform.position.x - .6f, transform.position.y, transform.position.z);
        }

        if (player.GetComponent<playerMovement>().leftFacing == true)
        {
            transform.position = new Vector3(transform.position.x + .6f, transform.position.y, transform.position.z);
        }
    }
    
    void meleeReset()
    {
        meleeAllowed = true;
    }


    void OnTriggerEnter2D(Collider2D collision)
    {
        if (fightmode)
        {
            if (collision.gameObject.tag == "meleeEnemy")
            {
                collision.gameObject.GetComponent<meleeEnemy>().decreaseHealth();
            }

            if (collision.gameObject.tag == "rangedEnemy")
            {
                collision.gameObject.GetComponent<rangedEnemy>().decreaseHealth();
            }

            if (collision.gameObject.tag == "bossEnemy")
            {
                collision.gameObject.GetComponent<bossEnemy>().decreaseHealth();
            }

            Rigidbody2D erb;
            erb = collision.gameObject.GetComponent<Rigidbody2D>();

            if (collision.gameObject.transform.position.x > transform.position.x)
            {
                erb.AddForce(Vector2.right * hurtForce, ForceMode2D.Impulse);
                erb.AddForce(Vector2.up * hurtForceUp, ForceMode2D.Impulse);
            }

            if (collision.gameObject.transform.position.x < transform.position.x)
            {
                erb.AddForce(Vector2.left * hurtForce, ForceMode2D.Impulse);
                erb.AddForce(Vector2.up * hurtForceUp, ForceMode2D.Impulse);
            }
        }
    }

}
